import Image from "next/image"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import NavbarNews from "@/components/NavbarNews"

// Dummy data untuk artikel berita
const newsArticles = {
  "pik-2-development": {
    title: "PIK 2 dalam Pembangunan Besar. Bagaimana Dampaknya pada Sektor Properti?",
    category: "Market Trends",
    date: "23 April 2023",
    author: "Kompas by Hilda B",
    image: "/placeholder.svg?height=600&width=1200",
    tags: ["#PIK2", "#Properti", "#Pembangunan"],
    content: [
      "Pantai Indah Kapuk 2 (PIK 2) telah menjadi salah satu proyek pembangunan terbesar di Jakarta dalam beberapa tahun terakhir. Dengan luas area mencapai 1.000 hektar, proyek ini diproyeksikan akan menjadi kawasan hunian dan komersial premium yang mengubah wajah Jakarta Utara.",
      "Menurut data dari Asosiasi Real Estate Indonesia (REI), nilai investasi untuk proyek PIK 2 diperkirakan mencapai Rp 150 triliun. Angka yang fantastis ini menunjukkan besarnya potensi dan dampak yang akan dihasilkan oleh proyek tersebut terhadap sektor properti secara keseluruhan.",
      '"Pembangunan PIK 2 memberikan dampak signifikan terhadap harga properti di sekitarnya," ujar Dr. Bambang Setiawan, pakar properti dari Universitas Indonesia. "Dalam dua tahun terakhir, kami mencatat kenaikan harga tanah di area sekitar PIK 2 mencapai 30-40 persen."',
      "Fenomena ini tidak hanya terjadi di sekitar lokasi proyek, tetapi juga memberikan efek riak ke berbagai wilayah di Jakarta. Pengembang properti lain mulai melirik kawasan Jakarta Utara sebagai lokasi potensial untuk proyek-proyek baru mereka.",
      "Selain itu, pembangunan infrastruktur pendukung seperti jalan tol, transportasi publik, dan fasilitas umum juga turut mendorong pertumbuhan sektor properti di kawasan tersebut. Akses yang semakin baik membuat nilai properti semakin meningkat.",
      'Namun, di balik pesatnya pembangunan dan kenaikan harga properti, muncul kekhawatiran mengenai potensi bubble properti. "Kita perlu memastikan bahwa pertumbuhan ini berkelanjutan dan didukung oleh fundamental ekonomi yang kuat," tambah Dr. Setiawan.',
      "Pemerintah sendiri telah mengambil langkah-langkah untuk mengatur pembangunan di kawasan tersebut, termasuk memastikan ketersediaan ruang terbuka hijau dan sistem drainase yang memadai untuk mencegah banjir.",
      "Bagi investor dan calon pembeli properti, PIK 2 menawarkan potensi keuntungan yang menarik. Namun, seperti halnya investasi properti lainnya, diperlukan analisis mendalam dan pertimbangan matang sebelum mengambil keputusan.",
    ],
    recommendedArticles: [
      {
        id: "market-trends-analysis",
        title: "Bagaimana Suku Bunga Mempengaruhi Tren Properti di Indonesia Tahun Ini?",
        category: "Market Trends",
        date: "1 minggu yang lalu",
        image: "/recommended-1.png",
      },
      {
        id: "5-faktor-yang-mempengaruhi",
        title: "5 Faktor yang Mempengaruhi Kenaikan Harga Properti di Perkotaan",
        category: "Insights",
        date: "1 minggu yang lalu",
        image: "/recommended-2.png",
      },
      {
        id: "policies-regulations",
        title: "Jenis Pajak Properti Yang Harus Diketahui Pengusaha Bisnis Properti",
        category: "Policies & Regulations",
        date: "3 jam yang lalu",
        image: "/recommended-3.png",
      },
    ],
  },
  "68-persen-tanah": {
    title: "68 Persen Tanah dan Kekayaan Indonesia Dikuasai oleh Satu Persen Kelompok",
    category: "Ekonomi",
    date: "23 April 2023",
    author: "Kompas by Hilda B",
    image: "/grid-1.png",
    tags: ["#Tanah", "#Ketimpangan", "#Ekonomi"],
    content: [
      "Ketimpangan distribusi tanah di Indonesia telah mencapai angka yang mengkhawatirkan. Hasil riset terbaru menunjukkan bahwa sekitar 68% tanah di Indonesia dikuasai oleh hanya 1% kelompok masyarakat luas.",
      "Data mencatat bahwa sejak 2013 hingga 2024, setidaknya terjadi 1.234 kasus konflik agraria yang melibatkan luas tanah mencapai 7,4 juta hektar, dengan dampak pada sekitar 1,9 juta keluarga. Direktur Eksekutif Konsorsium Pembaruan Agraria (KPA) menyatakan bahwa ketimpangan kepemilikan tanah di Indonesia di bawah kepemimpinan Presiden Prabowo Subianto harus menjadi agenda Reformasi Agraria sebagai upaya untuk mengatasi kesenjangan penguasaan tanah, pemulihan hak, pemindahan kekuasaan, pemberdayaan kelompok, pembangunan pedesaan, dan penjagaan hutan-hutan tropis.",
      '"Masalah ketimpangan kepemilikan tanah ini bukan hanya masalah ekonomi, tetapi juga masalah keadilan sosial," ujar Prof. Dr. Gunawan Wiradi, pakar agraria dari Institut Pertanian Bogor. "Tanah adalah sumber daya yang terbatas, dan distribusinya yang tidak merata dapat memicu konflik sosial yang berkepanjangan."',
      "Pemerintah telah mencanangkan program Reforma Agraria sebagai salah satu prioritas dalam Rencana Pembangunan Jangka Menengah Nasional (RPJMN) 2020-2024. Program ini bertujuan untuk mendistribusikan tanah kepada petani yang tidak memiliki lahan dan masyarakat miskin di pedesaan.",
      "Namun, implementasi program tersebut masih menghadapi berbagai tantangan, termasuk resistensi dari pihak-pihak yang memiliki kepentingan atas tanah tersebut, keterbatasan data pertanahan yang akurat, dan koordinasi antar lembaga pemerintah yang belum optimal.",
      "Menjelang KTT G20 2023 Penting Reforma Agraria! Sekretaris Jenderal KPA, Dewi Kartika, menegaskan bahwa penerapan reforma agraria perlu mendapat perhatian khusus dari pemerintah dan gerakan reforma agraria. Dalam forum ini, mereka berharap dapat mendorong pemerintah untuk mengambil langkah konkret bagi pembela hak atas tanah dan lingkungan hidup, serta memperkuat kebijakan yang mendukung kedaulatan pangan, keadilan iklim, dan lain-lain.",
    ],
    recommendedArticles: [
      {
        id: "intellectual-property",
        title: "Hak Kekayaan Intelektual: Mengapa Itu Penting bagi Startup?",
        category: "Bisnis",
        date: "10 Mei 2023",
        image: "/grid-2.png",
      },
      {
        id: "buying-vs-renting",
        title: "Beli atau Sewa Properti? Ini Pertimbangan yang Harus Diketahui",
        category: "Properti",
        date: "5 Juni 2023",
        image: "/grid-3.png",
      },
      {
        id: "for-rent",
        title: "Tren Sewa Properti 2024: Harga Naik, Permintaan Stabil",
        category: "Properti",
        date: "12 Juli 2023",
        image: "/grid-4.png",
      },
    ],
  },
  "market-trends-analysis": {
    title: "Bagaimana Suku Bunga Mempengaruhi Tren Properti di Indonesia Tahun Ini?",
    category: "Market Trends",
    date: "16 April 2023",
    author: "Kompas by Ahmad R",
    image: "/recommended-1.png",
    tags: ["#SukuBunga", "#Properti", "#Investasi"],
    content: [
      "Perubahan suku bunga acuan Bank Indonesia (BI) telah memberikan dampak signifikan terhadap pasar properti di Indonesia sepanjang tahun ini. Dengan suku bunga yang relatif stabil pada level 5,75%, pasar properti menunjukkan tanda-tanda pemulihan setelah terpukul oleh pandemi COVID-19.",
      '"Stabilitas suku bunga memberikan kepastian bagi investor dan pembeli properti," ujar Hendra Ciputra, Ketua Umum DPP REI (Real Estate Indonesia). "Hal ini tercermin dari peningkatan transaksi properti sebesar 15% pada kuartal kedua tahun 2023 dibandingkan periode yang sama tahun lalu."',
      "Namun, tantangan masih tetap ada. Inflasi yang meningkat dan ketidakpastian ekonomi global masih menjadi faktor yang mempengaruhi keputusan investasi di sektor properti. Bank Indonesia diperkirakan akan mempertahankan suku bunga acuan pada level saat ini hingga akhir tahun, meskipun terdapat tekanan untuk menaikkannya guna mengendalikan inflasi.",
      "Bagi konsumen, suku bunga kredit pemilikan rumah (KPR) menjadi pertimbangan utama dalam keputusan pembelian properti. Saat ini, rata-rata suku bunga KPR berkisar antara 7-9% per tahun, tergantung pada bank dan jangka waktu kredit.",
      '"Kami melihat adanya peningkatan permintaan KPR, terutama untuk properti di segmen menengah," kata Budi Santoso, Direktur Konsumer Bank Mandiri. "Program pemerintah seperti FLPP (Fasilitas Likuiditas Pembiayaan Perumahan) juga turut mendorong permintaan di segmen perumahan rakyat."',
      "Di sisi lain, pengembang properti juga harus menyesuaikan strategi mereka dalam menghadapi fluktuasi suku bunga. Beberapa pengembang menawarkan skema pembayaran yang lebih fleksibel dan insentif khusus untuk menarik pembeli.",
      '"Kami menawarkan program cicilan dengan bunga tetap selama dua tahun pertama untuk memberikan kepastian bagi pembeli," jelas Anita Wijaya, Marketing Director PT Ciputra Development Tbk.',
      "Secara keseluruhan, pasar properti Indonesia diproyeksikan akan terus tumbuh moderat sepanjang tahun 2023, dengan pertumbuhan sekitar 3-5%. Segmen perumahan menengah dan apartemen di kota-kota besar seperti Jakarta, Surabaya, dan Bandung diperkirakan akan memimpin pertumbuhan tersebut.",
    ],
    recommendedArticles: [
      {
        id: "pik-2-development",
        title: "PIK 2 dalam Pembangunan Besar. Bagaimana Dampaknya pada Sektor Properti?",
        category: "Market Trends",
        date: "12 jam yang lalu",
        image: "/placeholder.svg?height=400&width=600",
      },
      {
        id: "5-faktor-yang-mempengaruhi",
        title: "5 Faktor yang Mempengaruhi Kenaikan Harga Properti di Perkotaan",
        category: "Insights",
        date: "1 minggu yang lalu",
        image: "/recommended-2.png",
      },
      {
        id: "investment",
        title: "Investasi Properti: Peluang dan Tantangan di Tahun 2024",
        category: "Keuangan",
        date: "21 Agustus 2023",
        image: "/grid-5.png",
      },
    ],
  },
  // Tambahkan artikel lainnya dengan format yang sama
}

export default function NewsDetailPage({ params }: { params: { slug: string } }) {
  const { slug } = params
  const article = newsArticles[slug as keyof typeof newsArticles]

  if (!article) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <h1 className="text-2xl font-bold">Artikel tidak ditemukan</h1>
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-white">
      <NavbarNews />

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Breadcrumb dan Navigasi Kembali */}
        <div className="mb-8">
          <Link href="/news" className="inline-flex items-center text-[#17488D] hover:underline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Kembali ke Berita
          </Link>
        </div>

        {/* Header Artikel */}
        <div className="mb-6">
          <div className="mb-2">
            <span className="text-[#17488D] font-semibold font-ubuntu">{article.category}</span>
            <span className="text-black ml-1"> •</span>
            <span className="text-black font-semibold text-sm ml-2">{article.date}</span>
          </div>

          <h1 className="text-3xl md:text-4xl font-bold text-black font-ubuntu-mono mb-4">{article.title}</h1>

          <div className="flex items-center text-sm text-gray-600 mb-4">
            <span>{article.author}</span>
          </div>

          <div className="flex space-x-4 text-sm text-[#17488D] font-extralight mb-6">
            {article.tags.map((tag, index) => (
              <span key={index}>{tag}</span>
            ))}
          </div>
        </div>

        {/* Gambar Utama */}
        <div className="mb-8">
          <Image
            src={article.image || "/placeholder.svg"}
            alt={article.title}
            width={1200}
            height={600}
            className="rounded-lg w-full object-cover"
          />
        </div>

        {/* Konten Artikel */}
        <div className="prose max-w-none mb-12">
          {article.content.map((paragraph, index) => (
            <p key={index} className="mb-4 text-base leading-relaxed text-gray-800">
              {paragraph}
            </p>
          ))}
        </div>

        {/* Artikel Terkait */}
        <div className="border-t pt-8">
          <h2 className="text-xl font-bold mb-6 text-black">Artikel Terkait</h2>

          <div className="grid md:grid-cols-3 gap-6">
            {article.recommendedArticles.map((rec) => (
              <Link href={`/news/${rec.id}`} key={rec.id} className="group">
                <div className="mb-3">
                  <Image
                    src={rec.image || "/placeholder.svg"}
                    alt={rec.title}
                    width={400}
                    height={225}
                    className="rounded-lg w-full object-cover aspect-video"
                  />
                </div>
                <div>
                  <div className="mb-1">
                    <span className="text-[#17488D] text-sm font-bold font-ubuntu">{rec.category}</span>
                    <span className="text-black ml-1"> •</span>
                    <span className="text-black text-xs ml-2 font-semibold">{rec.date}</span>
                  </div>
                  <h3 className="font-inter text-sm font-bold text-black group-hover:text-[#17488D] transition-colors">
                    {rec.title}
                  </h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}

